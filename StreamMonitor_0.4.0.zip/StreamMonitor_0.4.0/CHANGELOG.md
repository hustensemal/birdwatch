# Changelog

## 0.4.0 – Release

- Shelly-/Pumpenmonitor über `Shelly.GetStatus`
- Kompaktes OBS-Overlay für Wasserstand, Erkennung, Pumpe und Stream
- Windows-Autostart direkt im Tray aktivierbar und deaktivierbar
- Eigene Statusseite unter `/status.html`
- Einheitlicher Startblock im Log
- Robustere Initialisierung der Statusdatei
- Autostart-Verknüpfung verweist korrekt auf den Installationsordner

## 0.3.9

- Adaptive Hysterese
- Referenzbestand und Referenzarchiv
