# StreamMonitor 0.4.0

Erste für den Dauerbetrieb vorgesehene Release-Version.

## Einrichtung

1. `EINRICHTEN.cmd` ausführen.
2. In `config.json` RTMP-Zugang und OBS-WebSocket-Passwort eintragen.
3. Die Shelly-Adresse unter `pump_monitor.url` prüfen.
4. `StreamMonitor_starten.vbs` starten.

## Autostart

Im Tray-Menü kann **Beim Windows-Start starten** jederzeit aktiviert oder deaktiviert werden. Der Haken zeigt den tatsächlich vorhandenen Windows-Autostart-Eintrag an.

## Overlay

OBS-Browserquelle: `http://127.0.0.1:8765/`

Empfohlene Größe: etwa 190 × 125 Pixel.

Statusseite: `http://127.0.0.1:8765/status.html`

## Hinweise

Die Wasserstandserkennung bleibt experimentell. Pumpenstatus und Streamstatus werden unabhängig davon angezeigt.
