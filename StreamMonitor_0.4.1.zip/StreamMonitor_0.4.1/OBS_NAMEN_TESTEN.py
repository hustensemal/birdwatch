import json
from pathlib import Path
import sys
import obsws_python as obs

base = Path(__file__).resolve().parent
cfg = json.loads((base / "config.json").read_text(encoding="utf-8"))["obs_monitor"]
password = str(cfg.get("password", ""))

if not password or "PASSWORT" in password.upper() or password.startswith("HIER_LOKAL_"):
    print("FEHLER: In config.json ist noch kein echtes OBS-WebSocket-Passwort eingetragen.")
    print("Bitte unter obs_monitor -> password das Passwort aus OBS eintragen.")
    input("\nEnter zum Schließen …")
    sys.exit(2)

try:
    client = obs.ReqClient(
        host=cfg.get("host", "127.0.0.1"),
        port=int(cfg.get("port", 4455)),
        password=password,
        timeout=cfg.get("timeout_seconds", 8),
    )
except Exception as exc:
    print("OBS-Verbindung fehlgeschlagen.")
    print(f"Host: {cfg.get('host', '127.0.0.1')}  Port: {cfg.get('port', 4455)}")
    print("Prüfe in OBS: Werkzeuge > WebSocket-Servereinstellungen")
    print("- WebSocket-Server aktiviert")
    print("- Port stimmt überein")
    print("- Passwort stimmt exakt überein")
    print(f"\nTechnischer Fehler: {type(exc).__name__}: {exc}")
    input("\nEnter zum Schließen …")
    sys.exit(1)

try:
    scenes = client.get_scene_list().scenes
    print("\nOBS-Szenen und enthaltene Elemente:\n")
    for scene in scenes:
        name = scene.get("sceneName", scene.get("scene_name", "?")) if isinstance(scene, dict) else str(scene)
        print(f"[{name}]")
        try:
            items = client.get_scene_item_list(name).scene_items
            for item in items:
                if isinstance(item, dict):
                    print(f"  - {item.get('sourceName', item.get('source_name', '?'))}")
                else:
                    print(f"  - {item}")
        except Exception as exc:
            print("  (nicht lesbar:", exc, ")")
finally:
    client.disconnect()
input("\nEnter zum Schließen …")
