from __future__ import annotations

import re

import base64
import json
import logging
import os
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

import cv2
import numpy as np

try:
    import obsws_python as obs
except ImportError:
    obs = None

try:
    import pystray
    from PIL import Image, ImageDraw
except ImportError:
    pystray = None
    Image = None
    ImageDraw = None

BASE = Path(__file__).resolve().parent
CFG_FILE = BASE / "config.json"
STATUS_FILE = BASE / "overlay" / "status.json"
LOG_FILE = BASE / "logs" / "streammonitor.log"
REF_DIR = BASE / "data" / "references"
REF_ARCHIVE_DIR = REF_DIR / "archive"
REFERENCE_REPORT = REF_DIR / "Referenzbestand.txt"
SNAP_DIR = BASE / "data" / "snapshots"
STREAMERBOT_DIR = BASE / "streamerbot"
LAST_WATER_FRAME: np.ndarray | None = None
LAST_WATER_INFO: dict[str, Any] = {}
LAST_WATER_LOCK = threading.Lock()
OBS_EVENT_DIR = BASE / "data" / "obs_events"
I18N_FILE = BASE / "i18n.json"
VERSION = "0.4.1"
AUTOSTART_NAME = "StreamMonitor.lnk"


class WaterLevel(Enum):
    FULL = ("full", 100)
    GOOD = ("good", 75)
    LOW = ("low", 35)
    ALMOST_EMPTY = ("almost_empty", 10)
    EMPTY = ("empty", 0)

    @property
    def key(self) -> str:
        return self.value[0]

    @property
    def percent(self) -> int:
        return self.value[1]

    @classmethod
    def from_key(cls, key: str) -> "WaterLevel":
        for level in cls:
            if level.key == key:
                return level
        raise ValueError(f"Unbekannter Wasserstand: {key}")


class BowlCondition(Enum):
    LIQUID = "liquid"
    FROZEN = "frozen"
    SNOW_COVERED = "snow_covered"
    OBSTRUCTED = "obstructed"
    UNKNOWN = "unknown"


class MeasurementQuality(Enum):
    VALID = "valid"
    UNCERTAIN = "uncertain"
    OBSTRUCTED = "obstructed"
    UNAVAILABLE = "unavailable"


class RecognitionRating(Enum):
    VERY_LIKELY = "very_likely"
    LIKELY = "likely"
    VAGUE = "vague"
    UNCERTAIN = "uncertain"
    UNAVAILABLE = "unavailable"


_TRANSLATIONS: dict[str, Any] = {}
_LANGUAGE = "de"


def load_translations(language: str) -> None:
    global _TRANSLATIONS, _LANGUAGE
    _LANGUAGE = language
    try:
        all_translations = json.loads(I18N_FILE.read_text(encoding="utf-8"))
        _TRANSLATIONS = all_translations.get(language) or all_translations.get("de", {})
    except Exception:
        _TRANSLATIONS = {}


def tr(group: str, key: str, fallback: str | None = None) -> str:
    value = _TRANSLATIONS.get(group, {}).get(key)
    return str(value if value is not None else (fallback if fallback is not None else key))


class SecretMaskFilter(logging.Filter):
    """Maskiert bekannte Geheimnisse in Logmeldungen."""

    def __init__(self, secrets: list[str] | None = None):
        super().__init__()
        self.secrets = [secret for secret in (secrets or []) if secret]

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        for secret in self.secrets:
            message = message.replace(secret, "********")
        record.msg = message
        record.args = ()
        return True


def setup_log(secrets: list[str] | None = None) -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    handlers = [
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ]
    secret_filter = SecretMaskFilter(secrets)
    for handler in handlers:
        handler.addFilter(secret_filter)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=handlers,
        force=True,
    )
    # obsws-python protokolliert Verbindungsparameter inklusive Passwort auf INFO.
    logging.getLogger("obsws_python").setLevel(logging.WARNING)


def load_cfg() -> dict[str, Any]:
    return json.loads(CFG_FILE.read_text(encoding="utf-8"))


def atomic_json_write(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def write_streamerbot_exports(water: dict[str, Any], cfg: dict[str, Any]) -> None:
    """Export the confirmed water state for Streamer.Bot and similar clients."""
    export_cfg = cfg.get("streamerbot_export", {})
    if not bool(export_cfg.get("enabled", True)):
        return
    STREAMERBOT_DIR.mkdir(parents=True, exist_ok=True)
    state = str(water.get("state", "unknown"))
    block_full = bool(export_cfg.get("block_water_when_full", True))
    allowed = state not in {"full", "unknown", "not_measurable", "calibration", "offline", "disabled"}
    if state == "full" and not block_full:
        allowed = True
    status = {
        "level": state,
        "label": water.get("label", state),
        "water_allowed": allowed,
        "confirmed": state in {level.key for level in WaterLevel},
        "measurement_quality": water.get("measurement_quality"),
        "recognition": water.get("recognition"),
        "updated": water.get("updated"),
        "last_success": water.get("last_success"),
    }
    atomic_json_write(STREAMERBOT_DIR / "water_status.json", status)
    tmp = STREAMERBOT_DIR / "water_level.txt.tmp"
    tmp.write_text(state, encoding="utf-8")
    os.replace(tmp, STREAMERBOT_DIR / "water_level.txt")
    tmp = STREAMERBOT_DIR / "water_allowed.txt.tmp"
    tmp.write_text("true" if allowed else "false", encoding="utf-8")
    os.replace(tmp, STREAMERBOT_DIR / "water_allowed.txt")


def load_status() -> dict[str, Any]:
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text(encoding="utf-8"))
        except Exception:
            logging.warning("Statusdatei war nicht lesbar und wird neu aufgebaut.")
    return {"water": {}, "cameras": {}, "pump": {}, "updated": None}


def update_status(section: str, key: str | None, value: dict[str, Any]) -> None:
    data = load_status()
    if key is None:
        data[section] = value
    else:
        data.setdefault(section, {})[key] = value
    data["updated"] = datetime.now().astimezone().isoformat(timespec="seconds")
    atomic_json_write(STATUS_FILE, data)


def write_water_status(
    state: str,
    detail: str = "",
    confidence: float | None = None,
    recognition: RecognitionRating = RecognitionRating.UNAVAILABLE,
    *,
    raw_state: str | None = None,
    candidate_count: int = 0,
    candidate_required: int = 0,
    bowl_condition: BowlCondition = BowlCondition.LIQUID,
    quality: MeasurementQuality = MeasurementQuality.VALID,
    top_matches: list[dict[str, Any]] | None = None,
) -> None:
    old = load_status().get("water", {})
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    valid_keys = {level.key for level in WaterLevel}
    percent = WaterLevel.from_key(state).percent if state in valid_keys else None
    value = {
        "state": state,
        "label": tr("water_levels", state),
        "percent": percent,
        "raw_state": raw_state or state,
        "raw_label": tr("water_levels", raw_state or state),
        "confidence": confidence,
        "recognition": recognition.value,
        "recognition_label": tr("recognition", recognition.value),
        "candidate_count": candidate_count,
        "candidate_required": candidate_required,
        "bowl_condition": bowl_condition.value,
        "bowl_condition_label": tr("bowl_conditions", bowl_condition.value),
        "measurement_quality": quality.value,
        "measurement_quality_label": tr("measurement_quality", quality.value),
        "confidence_percent": round(confidence * 100) if confidence is not None else None,
        "top_matches": top_matches or [],
        "updated": now,
        "last_success": now if state in valid_keys else old.get("last_success"),
        "detail": detail,
    }
    update_status("water", None, value)
    write_streamerbot_exports(value, globals().get("_ACTIVE_WATER_CFG", {}))


def write_camera_status(name: str, state: str, detail: str = "", **extra: Any) -> None:
    value = {
        "state": state,
        "label": {
            "ok": "Bild bewegt sich",
            "suspected": "Freeze-Verdacht",
            "recovering": "Quelle wird neu geladen",
            "recovered": "Bild wieder aktiv",
            "frozen": "Bild vermutlich eingefroren",
            "offline": "OBS nicht erreichbar",
            "error": "Prüfung fehlgeschlagen",
            "disabled": "Deaktiviert",
            "starting": "Startet …",
        }.get(state, state),
        "detail": detail,
        "updated": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    value.update(extra)
    update_status("cameras", name, value)



def write_pump_status(state: str, detail: str = "", *, output: bool | None = None) -> None:
    labels = {
        "online": "Erreichbar",
        "offline": "Nicht erreichbar",
        "starting": "Startet …",
        "disabled": "Deaktiviert",
        "error": "Prüfung fehlgeschlagen",
    }
    update_status("pump", None, {
        "state": state,
        "label": labels.get(state, state),
        "detail": detail,
        "output": output,
        "updated": datetime.now().astimezone().isoformat(timespec="seconds"),
    })


def aggregate_stream_status() -> dict[str, str]:
    cameras = load_status().get("cameras", {})
    states = [item.get("state", "starting") for item in cameras.values() if item.get("state") != "disabled"]
    if not states:
        return {"state": "starting", "label": "Startet …"}
    if any(state in {"offline", "error", "frozen"} for state in states):
        return {"state": "offline", "label": "Störung"}
    if any(state in {"suspected", "recovering"} for state in states):
        return {"state": "warning", "label": "Prüfen"}
    if all(state in {"ok", "recovered"} for state in states):
        return {"state": "online", "label": "In Ordnung"}
    return {"state": "starting", "label": "Startet …"}

def crop_roi(frame: np.ndarray, roi: list[int]) -> np.ndarray:
    x, y, w, h = roi
    fh, fw = frame.shape[:2]
    x = max(0, min(int(x), fw - 1))
    y = max(0, min(int(y), fh - 1))
    w = max(1, min(int(w), fw - x))
    h = max(1, min(int(h), fh - y))
    return frame[y : y + h, x : x + w].copy()


def water_roi_pixels(frame: np.ndarray, cfg: dict[str, Any]) -> list[int]:
    """Return the configured water ROI in pixels for the actual frame size."""
    fh, fw = frame.shape[:2]
    normalized = cfg.get("roi_normalized")
    if normalized is not None:
        if len(normalized) != 4:
            raise ValueError("water_monitor.roi_normalized muss vier Werte enthalten.")
        nx, ny, nw, nh = (float(value) for value in normalized)
        if not (0 <= nx < 1 and 0 <= ny < 1 and 0 < nw <= 1 and 0 < nh <= 1):
            raise ValueError("roi_normalized muss innerhalb 0..1 liegen.")
        return [
            round(nx * fw),
            round(ny * fh),
            max(1, round(nw * fw)),
            max(1, round(nh * fh)),
        ]
    legacy = cfg.get("roi")
    if legacy is None:
        raise ValueError("Weder roi_normalized noch roi ist konfiguriert.")
    return [int(value) for value in legacy]


def crop_water_roi(frame: np.ndarray, cfg: dict[str, Any]) -> np.ndarray:
    return crop_roi(frame, water_roi_pixels(frame, cfg))


def capture_rtmp(cfg: dict[str, Any]) -> list[np.ndarray]:
    cap = cv2.VideoCapture(cfg["stream_url"], cv2.CAP_FFMPEG)
    timeout_ms = int(cfg["connect_timeout_seconds"] * 1000)
    cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, timeout_ms)
    cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, timeout_ms)
    if not cap.isOpened():
        raise RuntimeError("RTMP-Stream konnte nicht geöffnet werden.")
    for _ in range(20):
        cap.read()
        time.sleep(0.05)
    frames: list[np.ndarray] = []
    for i in range(cfg["sample_count"]):
        ok, frame = cap.read()
        if ok and frame is not None:
            frames.append(frame)
        if i + 1 < cfg["sample_count"]:
            time.sleep(cfg["sample_spacing_seconds"])
    cap.release()
    if not frames:
        raise RuntimeError("Keine Bilder vom Stream empfangen.")
    return frames


REFERENCE_CAPTURE_LOCK = threading.Lock()


def capture_reference_frames(cfg: dict[str, Any]) -> list[np.ndarray]:
    """Capture individual full frames for a new reference series."""
    tray_cfg = cfg.get("tray_reference_capture", {})
    count = max(1, int(tray_cfg.get("count", 5)))
    spacing = max(0.0, float(tray_cfg.get("spacing_seconds", 0.5)))
    cap = cv2.VideoCapture(cfg["stream_url"], cv2.CAP_FFMPEG)
    timeout_ms = int(float(cfg.get("connect_timeout_seconds", 12)) * 1000)
    cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, timeout_ms)
    cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, timeout_ms)
    if not cap.isOpened():
        raise RuntimeError("RTMP-Stream konnte nicht geöffnet werden.")
    try:
        # Discard buffered/old frames before starting the series.
        for _ in range(20):
            cap.read()
            time.sleep(0.05)
        frames: list[np.ndarray] = []
        for index in range(count):
            ok, frame = cap.read()
            if not ok or frame is None:
                logging.warning("Referenzaufnahme %s/%s konnte nicht gelesen werden.", index + 1, count)
            else:
                frames.append(frame.copy())
            if index + 1 < count:
                time.sleep(spacing)
        if not frames:
            raise RuntimeError("Keine Bilder vom Stream empfangen.")
        return frames
    finally:
        cap.release()


def reference_counts() -> dict[str, int]:
    return {level.key: len(reference_paths_for_state(level.key)) for level in WaterLevel}


def archived_reference_counts() -> dict[str, int]:
    counts: dict[str, int] = {}
    for level in WaterLevel:
        folder = REF_ARCHIVE_DIR / level.key
        counts[level.key] = len([p for p in folder.glob("*") if p.is_file() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}]) if folder.exists() else 0
    return counts


def write_reference_report() -> Path:
    """Create a human-readable overview of active and archived references."""
    REF_DIR.mkdir(parents=True, exist_ok=True)
    REF_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    active = reference_counts()
    archived = archived_reference_counts()
    lines = [
        f"StreamMonitor {VERSION} – Referenzbestand",
        f"Erstellt: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        "",
        "Aktive Referenzen werden bei der Wasserstandsmessung verwendet.",
        "Archivierte Referenzen werden nicht ausgewertet.",
        r"Zum Deaktivieren kann eine Bilddatei in data\references\archive\<Klasse> verschoben werden.",
        r"Zum Reaktivieren wird sie zurück in data\references\<Klasse> verschoben.",
        "",
    ]
    for level in WaterLevel:
        folder = REF_DIR / level.key
        archive = REF_ARCHIVE_DIR / level.key
        folder.mkdir(parents=True, exist_ok=True)
        archive.mkdir(parents=True, exist_ok=True)
        active_files = sorted((x for x in folder.iterdir() if x.is_file() and x.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}), key=lambda x: x.stat().st_mtime, reverse=True)
        archived_files = sorted((x for x in archive.iterdir() if x.is_file() and x.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}), key=lambda x: x.stat().st_mtime, reverse=True)
        lines.append(f"[{tr('water_levels', level.key, level.key)} / {level.key}] aktiv: {active[level.key]} | archiviert: {archived[level.key]}")
        for item in active_files:
            changed = datetime.fromtimestamp(item.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            lines.append(f"  AKTIV   {changed}  {item.name}")
        for item in archived_files:
            changed = datetime.fromtimestamp(item.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            lines.append(f"  ARCHIV  {changed}  {item.name}")
        lines.append("")
    REFERENCE_REPORT.write_text("\n".join(lines), encoding="utf-8")
    return REFERENCE_REPORT


def open_file(path: Path) -> None:
    try:
        os.startfile(str(path))  # type: ignore[attr-defined]
    except AttributeError:
        webbrowser.open(path.resolve().as_uri())


def create_reference_series(
    state: str,
    water_cfg: dict[str, Any],
    notify: Callable[[str, str], None] | None = None,
) -> None:
    """Capture and save a timestamped reference series in a background thread."""
    label = tr("water_levels", state, state)
    if not REFERENCE_CAPTURE_LOCK.acquire(blocking=False):
        message = "Eine Referenzaufnahme läuft bereits."
        logging.warning(message)
        if notify:
            notify("StreamMonitor", message)
        return
    try:
        logging.info("Neue Wasser-Referenz angefordert: %s", state)
        frames = capture_reference_frames(water_cfg)
        folder = REF_DIR / state
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        saved: list[Path] = []
        for index, frame in enumerate(frames, start=1):
            path = folder / f"{state}_{stamp}_{index:02d}.png"
            if not cv2.imwrite(str(path), frame):
                raise RuntimeError(f"Referenzbild konnte nicht gespeichert werden: {path}")
            saved.append(path)
            logging.info("Wasser-Referenz gespeichert: %s", path)
        counts = reference_counts()
        logging.info(
            "Wasser-Referenzen neu verfügbar | full %s | good %s | low %s | almost_empty %s | empty %s",
            counts["full"], counts["good"], counts["low"], counts["almost_empty"], counts["empty"],
        )
        message = f"{len(saved)} Referenzbilder für „{label}“ gespeichert."
        if notify:
            notify("StreamMonitor", message)
    except Exception as exc:
        logging.exception("Wasser-Referenzaufnahme für %s fehlgeschlagen", state)
        if notify:
            notify("StreamMonitor", f"Referenzaufnahme fehlgeschlagen: {exc}")
    finally:
        REFERENCE_CAPTURE_LOCK.release()


def vector(img: np.ndarray) -> np.ndarray:
    img = cv2.resize(img, (96, 64), interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = np.zeros(gray.shape, np.uint8)
    cv2.ellipse(mask, (48, 36), (39, 22), 0, 0, 360, 255, -1)
    m = mask > 0
    edges = cv2.Canny(gray, 45, 120)
    return np.array(
        [
            lab[:, :, 0][m].mean() / 255,
            lab[:, :, 0][m].std() / 128,
            lab[:, :, 1][m].mean() / 255,
            lab[:, :, 2][m].mean() / 255,
            hsv[:, :, 1][m].mean() / 255,
            hsv[:, :, 2][m].mean() / 255,
            (gray[m] < 70).mean(),
            (gray[m] < 110).mean(),
            (gray[m] > 190).mean(),
            (edges[m] > 0).mean(),
        ],
        dtype=np.float32,
    )


def reference_paths_for_state(state: str) -> list[Path]:
    """Return class-folder references plus compatible legacy flat files.

    The preferred layout is data/references/<state>/*.png. For existing
    installations, files such as full1.png or almost_empty2.png directly in
    data/references are also accepted.
    """
    paths: list[Path] = []
    folder = REF_DIR / state
    folder.mkdir(parents=True, exist_ok=True)
    paths.extend(path for path in folder.iterdir() if path.is_file())

    # Longest names are important conceptually (almost_empty before empty),
    # but each state is checked independently here using an exact prefix rule.
    for path in REF_DIR.iterdir():
        if not path.is_file():
            continue
        stem = path.stem.lower().replace("-", "_")
        if stem == state or stem.startswith(state + "_") or re.fullmatch(re.escape(state) + r"\d+", stem):
            paths.append(path)

    # Avoid duplicate processing if the same path was collected twice.
    return sorted({path.resolve(): path for path in paths}.values(), key=lambda item: item.name.lower())


def normalize_water_roi(roi: np.ndarray, cfg: dict[str, Any]) -> np.ndarray:
    """Moderately normalize ROI illumination for diagnostic comparison only."""
    if not bool(cfg.get("brightness_normalization_enabled", True)):
        return roi.copy()
    lab = cv2.cvtColor(roi, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clip = float(cfg.get("brightness_normalization_clip_limit", 2.0))
    grid = int(cfg.get("brightness_normalization_grid", 8))
    clahe = cv2.createCLAHE(clipLimit=max(0.1, clip), tileGridSize=(max(2, grid), max(2, grid)))
    l2 = clahe.apply(l)
    return cv2.cvtColor(cv2.merge((l2, a, b)), cv2.COLOR_LAB2BGR)


def normalized_class_scores(crops: list[np.ndarray], cfg: dict[str, Any]) -> tuple[dict[str, float], str | None]:
    """Compare a normalized ROI against normalized references without changing the official result."""
    if not bool(cfg.get("brightness_normalization_enabled", True)):
        return {}, None
    refs, missing = references(cfg)
    if missing:
        return {}, None
    current = np.median(np.vstack([vector(normalize_water_roi(crop, cfg)) for crop in crops]), axis=0)
    scores: dict[str, float] = {}
    for state, items in refs.items():
        distances = []
        for _, _, roi in items:
            ref = vector(normalize_water_roi(roi, cfg))
            distances.append(float(np.linalg.norm(ref - current)))
        scores[state] = aggregate_reference_score(distances, cfg)
    ordered = sorted(scores.items(), key=lambda item: item[1])
    return scores, (ordered[0][0] if ordered else None)


def references(cfg: dict[str, Any]) -> tuple[dict[str, list[tuple[str, np.ndarray, np.ndarray]]], list[str]]:
    refs: dict[str, list[tuple[str, np.ndarray, np.ndarray]]] = {}
    missing: list[str] = []
    full_frame = bool(cfg.get("reference_images_are_full_frame", True))
    minimum = max(1, int(cfg.get("minimum_reference_count_per_class", 1)))
    for state in (level.key for level in WaterLevel):
        vals: list[tuple[str, np.ndarray, np.ndarray]] = []
        for path in reference_paths_for_state(state):
            image = cv2.imread(str(path))
            if image is None:
                logging.warning("Referenzbild konnte nicht gelesen werden: %s", path)
                continue
            reference_roi = crop_water_roi(image, cfg) if full_frame else image
            vals.append((path.name, vector(reference_roi), reference_roi))
        refs[state] = vals
        if len(vals) < minimum:
            missing.append(state)
    return refs, missing


def aggregate_reference_score(distances: list[float], cfg: dict[str, Any]) -> float:
    """Build a robust class score from the best matching references."""
    if not distances:
        return float("inf")
    best_count = max(1, int(cfg.get("reference_score_best_count", 2)))
    selected = sorted(distances)[: min(best_count, len(distances))]
    method = str(cfg.get("reference_score_method", "mean_best")).lower()
    if method == "minimum":
        return float(selected[0])
    if method == "median_best":
        return float(np.median(selected))
    return float(np.mean(selected))



def trim_newest_folders(folder: Path, maximum: int) -> None:
    """Keep only the newest diagnostic folders."""
    folder.mkdir(parents=True, exist_ok=True)
    folders = sorted(
        (path for path in folder.iterdir() if path.is_dir()),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    for old in folders[max(1, maximum):]:
        import shutil
        shutil.rmtree(old, ignore_errors=True)


def save_water_diagnostics(
    crops: list[np.ndarray],
    per_class: dict[str, list[tuple[str, float, np.ndarray]]],
    scores: dict[str, float],
    cfg: dict[str, Any],
) -> Path | None:
    """Save visual evidence showing which pixels and references drive a result."""
    if not bool(cfg.get("diagnostics_enabled", True)):
        return None
    root = BASE / "diagnostics" / "water"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    folder = root / stamp
    folder.mkdir(parents=True, exist_ok=True)

    target_size = (192, 128)
    resized = [cv2.resize(crop, target_size, interpolation=cv2.INTER_AREA) for crop in crops]
    current = np.median(np.stack(resized).astype(np.float32), axis=0).astype(np.uint8)
    cv2.imwrite(str(folder / "00_current_bowl.png"), current)

    ordered = sorted(scores.items(), key=lambda item: item[1])
    report: dict[str, Any] = {
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "class_scores": {state: round(score, 6) for state, score in ordered},
        "classes": {},
        "note": "Helle Bereiche in den Differenzbildern weichen stärker vom aktuellen Bild ab.",
    }
    save_count = max(1, int(cfg.get("diagnostics_references_per_class", 2)))
    for class_index, (state, score) in enumerate(ordered, start=1):
        class_items = []
        for ref_index, (name, distance, roi) in enumerate(per_class[state][:save_count], start=1):
            reference = cv2.resize(roi, target_size, interpolation=cv2.INTER_AREA)
            diff = cv2.absdiff(current, reference)
            gray_diff = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            heatmap = cv2.applyColorMap(gray_diff, cv2.COLORMAP_TURBO)
            safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
            prefix = f"{class_index:02d}_{state}_{ref_index:02d}_{safe_name}"
            cv2.imwrite(str(folder / f"{prefix}_reference.png"), reference)
            cv2.imwrite(str(folder / f"{prefix}_difference.png"), diff)
            cv2.imwrite(str(folder / f"{prefix}_heatmap.png"), heatmap)
            class_items.append({"reference": name, "distance": round(distance, 6)})
        report["classes"][state] = {
            "score": round(score, 6),
            "references": class_items,
        }
    atomic_json_write(folder / "diagnostic.json", report)
    trim_newest_folders(root, int(cfg.get("diagnostics_max_folders", 30)))
    logging.info("Wasser-Diagnose gespeichert: %s", folder)
    return folder

def classify(
    crops: list[np.ndarray], cfg: dict[str, Any]
) -> tuple[str, float, str, MeasurementQuality, RecognitionRating, list[dict[str, Any]]]:
    """Classify by comparing the current image with multiple references per class."""
    refs, missing = references(cfg)
    if missing:
        return (
            "calibration",
            0.0,
            "Fehlende Referenzen: " + ", ".join(missing),
            MeasurementQuality.UNAVAILABLE,
            RecognitionRating.UNAVAILABLE,
            [],
        )

    current = np.median(np.vstack([vector(crop) for crop in crops]), axis=0)
    per_class: dict[str, list[tuple[str, float, np.ndarray]]] = {}
    scores: dict[str, float] = {}
    for state, items in refs.items():
        matches = [(name, float(np.linalg.norm(value - current)), roi) for name, value, roi in items]
        matches.sort(key=lambda item: item[1])
        per_class[state] = matches
        scores[state] = aggregate_reference_score([distance for _, distance, _ in matches], cfg)

    if cfg.get("log_reference_distances", True):
        logging.info(
            "Wasser-Klassenwerte | full %.3f | good %.3f | low %.3f | almost_empty %.3f | empty %.3f",
            scores["full"], scores["good"], scores["low"], scores["almost_empty"], scores["empty"],
        )
        detail_count = max(1, int(cfg.get("log_best_references_per_class", 2)))
        for state in (level.key for level in WaterLevel):
            details = " | ".join(
                f"{name} {distance:.3f}" for name, distance, _ in per_class[state][:detail_count]
            )
            logging.info("Wasser-Referenzen %s | %s", state, details)

    ordered = sorted(scores.items(), key=lambda item: item[1])
    diagnostic_folder = save_water_diagnostics(crops, per_class, scores, cfg)
    best, distance = ordered[0]
    second_state, second_distance = ordered[1]
    confidence = max(0.0, min(1.0, (second_distance - distance) / max(second_distance, 1e-6)))
    top_matches = [
        {
            "state": state,
            "label": tr("water_levels", state),
            "distance": round(score, 6),
            "best_reference": per_class[state][0][0] if per_class[state] else None,
            "reference_count": len(per_class[state]),
        }
        for state, score in ordered[:2]
    ]

    maximum_distance = float(cfg.get("maximum_reference_distance", 0.45))
    if distance > maximum_distance:
        return (
            "not_measurable",
            confidence,
            f"Kein plausibler Referenztreffer; bester Kandidat {best}; Klassenwert {distance:.3f}",
            MeasurementQuality.UNAVAILABLE,
            RecognitionRating.UNAVAILABLE,
            top_matches,
        )

    rating = recognition_rating(best, distance, second_state, second_distance, cfg)
    best_file = per_class[best][0][0]
    second_file = per_class[second_state][0][0]
    threshold = float(cfg.get("confidence_threshold", 0.12))
    prefix = "Referenzvergleich eingeschränkt" if confidence < threshold else "Referenzvergleich"
    detail = (
        f"{prefix}; Klassenwert {distance:.3f}; beste Referenz {best_file}; "
        f"zweite Klasse {second_state} {second_distance:.3f} ({second_file})"
        + (f"; Diagnose {diagnostic_folder}" if diagnostic_folder else "")
    )
    quality = MeasurementQuality.UNCERTAIN if confidence < threshold else MeasurementQuality.VALID
    return best, confidence, detail, quality, rating, top_matches


def recognition_rating(
    best_state: str,
    best_distance: float,
    second_state: str,
    second_distance: float,
    cfg: dict[str, Any],
) -> RecognitionRating:
    """Convert technical comparison values into a cautious viewer-facing rating.

    The absolute match is more important than the narrow gap between adjacent
    fill levels. This avoids misleading values such as "2.4 %" when FULL and
    GOOD are both plausible and the bowl is clearly near the top end.
    """
    maximum = float(cfg.get("maximum_reference_distance", 0.45))
    very_likely_distance = float(cfg.get("recognition_very_likely_distance", 0.16))
    likely_distance = float(cfg.get("recognition_likely_distance", 0.30))
    vague_distance = float(cfg.get("recognition_vague_distance", 0.38))

    if best_distance > maximum:
        return RecognitionRating.UNAVAILABLE

    order = [level.key for level in WaterLevel]
    try:
        adjacent = abs(order.index(best_state) - order.index(second_state)) == 1
    except ValueError:
        adjacent = False

    margin = max(0.0, second_distance - best_distance)
    relative_margin = margin / max(second_distance, 1e-6)

    # A good absolute match must not be presented as highly reliable when
    # another class is almost tied. The class margin therefore caps the rating.
    very_likely_margin = float(cfg.get("recognition_very_likely_relative_margin", 0.18))
    likely_margin = float(cfg.get("recognition_likely_relative_margin", 0.08))

    if relative_margin < likely_margin:
        return RecognitionRating.UNCERTAIN
    if best_distance <= very_likely_distance and relative_margin >= very_likely_margin:
        return RecognitionRating.VERY_LIKELY
    if best_distance <= likely_distance:
        return RecognitionRating.LIKELY if adjacent or relative_margin >= likely_margin else RecognitionRating.VAGUE
    if best_distance <= vague_distance:
        return RecognitionRating.VAGUE
    return RecognitionRating.UNCERTAIN


@dataclass
class WaterStateTracker:
    confirmed: WaterLevel | None = None
    candidate: WaterLevel | None = None
    candidate_count: int = 0
    invalid_count: int = 0
    fast_confirmed: bool = False
    state_changed: bool = False
    fast_check_remaining: int = 0

    def update(
        self,
        raw_state: str,
        cfg: dict[str, Any],
        *,
        best_distance: float | None = None,
        second_distance: float | None = None,
    ) -> tuple[str, int, int, MeasurementQuality]:
        required = max(1, int(cfg.get("hysteresis_confirmations", 3)))
        invalid_required = max(1, int(cfg.get("invalid_confirmations", 2)))
        valid_keys = {level.key for level in WaterLevel}
        self.fast_confirmed = False
        self.state_changed = False

        if raw_state not in valid_keys:
            self.invalid_count += 1
            self.candidate = None
            self.candidate_count = 0
            if self.confirmed is not None and self.invalid_count < invalid_required:
                return self.confirmed.key, self.invalid_count, invalid_required, MeasurementQuality.UNCERTAIN
            return raw_state, self.invalid_count, invalid_required, MeasurementQuality.UNAVAILABLE

        self.invalid_count = 0
        measured = WaterLevel.from_key(raw_state)
        if self.confirmed is None:
            self.confirmed = measured
            self.candidate = None
            self.candidate_count = 0
            return measured.key, 0, required, MeasurementQuality.VALID
        if measured == self.confirmed:
            self.candidate = None
            self.candidate_count = 0
            return self.confirmed.key, 0, required, MeasurementQuality.VALID

        adaptive = bool(cfg.get("adaptive_hysteresis_enabled", True))
        clear_required = max(1, int(cfg.get("adaptive_hysteresis_confirmations", 1)))
        max_best = float(cfg.get("adaptive_hysteresis_max_best_distance", 0.08))
        min_margin = float(cfg.get("adaptive_hysteresis_min_absolute_margin", 0.15))
        min_relative = float(cfg.get("adaptive_hysteresis_min_relative_margin", 0.50))
        clear = False
        if adaptive and best_distance is not None and second_distance is not None:
            margin = max(0.0, second_distance - best_distance)
            relative = margin / max(second_distance, 1e-6)
            clear = best_distance <= max_best and margin >= min_margin and relative >= min_relative

        effective_required = clear_required if clear else required
        if measured == self.candidate:
            self.candidate_count += 1
        else:
            self.candidate = measured
            self.candidate_count = 1
        if self.candidate_count >= effective_required:
            old_confirmed = self.confirmed
            self.confirmed = measured
            self.candidate = None
            self.candidate_count = 0
            self.fast_confirmed = clear and effective_required < required
            self.state_changed = old_confirmed != measured
            return self.confirmed.key, effective_required, effective_required, MeasurementQuality.VALID
        return self.confirmed.key, self.candidate_count, effective_required, MeasurementQuality.UNCERTAIN

def cleanup_dir(folder: Path, days: int) -> None:
    cutoff = time.time() - days * 86400
    folder.mkdir(parents=True, exist_ok=True)
    for path in folder.glob("*"):
        try:
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink()
        except OSError:
            pass


def measure_water(cfg: dict[str, Any], tracker: WaterStateTracker) -> None:
    global _ACTIVE_WATER_CFG, LAST_WATER_FRAME, LAST_WATER_INFO
    _ACTIVE_WATER_CFG = cfg
    if not cfg.get("enabled", True):
        write_water_status("disabled", quality=MeasurementQuality.UNAVAILABLE)
        return
    logging.info("Wasserstandsmessung gestartet")
    try:
        frames = capture_rtmp(cfg)
        crops = [crop_water_roi(frame, cfg) for frame in frames]
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if cfg["save_snapshots"]:
            SNAP_DIR.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(SNAP_DIR / f"{stamp}_frame.jpg"), frames[len(frames) // 2])
            cv2.imwrite(str(SNAP_DIR / f"{stamp}_bowl.jpg"), crops[len(crops) // 2])
        raw_state, confidence, detail, classification_quality, recognition, top_matches = classify(crops, cfg)
        normalized_scores, normalized_best = normalized_class_scores(crops, cfg)
        if normalized_best:
            logging.info("Wasser-Normalisierung | bester Kandidat %s | full %.3f | good %.3f | low %.3f | almost_empty %.3f | empty %.3f", normalized_best, normalized_scores.get("full", float("nan")), normalized_scores.get("good", float("nan")), normalized_scores.get("low", float("nan")), normalized_scores.get("almost_empty", float("nan")), normalized_scores.get("empty", float("nan")))
        best_distance = float(top_matches[0]["distance"]) if len(top_matches) >= 1 else None
        second_distance = float(top_matches[1]["distance"]) if len(top_matches) >= 2 else None
        confirmed_state, count, required, tracker_quality = tracker.update(
            raw_state,
            cfg,
            best_distance=best_distance,
            second_distance=second_distance,
        )
        quality = (
            MeasurementQuality.UNAVAILABLE
            if classification_quality == MeasurementQuality.UNAVAILABLE
            else MeasurementQuality.UNCERTAIN
            if classification_quality == MeasurementQuality.UNCERTAIN or tracker_quality == MeasurementQuality.UNCERTAIN
            else tracker_quality
        )
        if tracker.fast_confirmed:
            detail = f"Eindeutiger Treffer: adaptive Hysterese hat sofort bestätigt. {detail}"
        elif raw_state != confirmed_state and tracker_quality == MeasurementQuality.UNCERTAIN:
            detail = f"Kandidat {raw_state}: Bestätigung {count}/{required}; bisher {confirmed_state}. {detail}"
        with LAST_WATER_LOCK:
            LAST_WATER_FRAME = frames[len(frames) // 2].copy()
            LAST_WATER_INFO = {"confirmed_state": confirmed_state, "raw_state": raw_state, "recognition": recognition.value, "confidence": confidence, "updated": datetime.now().astimezone().isoformat(timespec="seconds"), "top_matches": top_matches}
        write_water_status(
            confirmed_state, detail, round(confidence, 3), recognition=recognition, raw_state=raw_state,
            candidate_count=count, candidate_required=required, quality=quality,
            top_matches=top_matches,
        )
        logging.info(
            "Wasser | Rohwert %s | bestätigt %s | Erkennung %s | Qualität %s | %s",
            raw_state, confirmed_state, recognition.value, quality.value, detail,
        )
    except Exception as exc:
        logging.exception("Wasserstandsmessung fehlgeschlagen")
        state, count, required, quality = tracker.update("offline", cfg)
        write_water_status(state, str(exc), raw_state="offline", candidate_count=count, candidate_required=required, quality=quality)
    cleanup_dir(SNAP_DIR, cfg["snapshot_retention_days"])


def show_water_roi_diagnostic() -> None:
    """Create and open a single diagnostic image from the last analyzed frame."""
    with LAST_WATER_LOCK:
        frame = None if LAST_WATER_FRAME is None else LAST_WATER_FRAME.copy()
        info = dict(LAST_WATER_INFO)
    if frame is None:
        raise RuntimeError("Es wurde noch keine Wasserstandsmessung durchgeführt.")
    cfg = globals().get("_ACTIVE_WATER_CFG", {})
    x, y, w, h = water_roi_pixels(frame, cfg)
    cv2.rectangle(frame, (x, y), (x + w, y + h), (60, 220, 80), 3)
    lines = [
        f"ROI | bestaetigt: {info.get('confirmed_state', '–')} | Rohwert: {info.get('raw_state', '–')}",
        f"Erkennung: {info.get('recognition', '–')} | Messsicherheit: {info.get('confidence', '–')}",
        f"Aufnahme: {info.get('updated', '–')}",
    ]
    y0 = 28
    for line in lines:
        cv2.rectangle(frame, (8, y0 - 20), (min(frame.shape[1] - 8, 720), y0 + 7), (0, 0, 0), -1)
        cv2.putText(frame, line, (14, y0), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (245, 245, 245), 1, cv2.LINE_AA)
        y0 += 30
    target = BASE / "diagnostics" / "water" / "latest_water_roi.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(target), frame)
    open_file(target)
    logging.info("Wasser-Diagnosebild mit ROI geöffnet: %s", target)


def decode_obs_screenshot(image_data: str) -> np.ndarray:
    encoded = image_data.split(",", 1)[-1]
    raw = base64.b64decode(encoded)
    image = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError("OBS-Screenshot konnte nicht dekodiert werden.")
    return image


def response_value(response: Any, *names: str) -> Any:
    for name in names:
        if hasattr(response, name):
            return getattr(response, name)
    data = getattr(response, "datain", None)
    if isinstance(data, dict):
        for name in names:
            if name in data:
                return data[name]
    raise AttributeError(f"Antwortfeld nicht gefunden: {', '.join(names)}")


def normalized_frame(image: np.ndarray, roi: list[int] | None = None) -> np.ndarray:
    if roi:
        image = crop_roi(image, roi)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, (160, 90), interpolation=cv2.INTER_AREA)
    return cv2.GaussianBlur(gray, (5, 5), 0)


def image_change(previous: np.ndarray, current: np.ndarray, pixel_threshold: int) -> tuple[float, float]:
    diff = cv2.absdiff(previous, current)
    mean_difference = float(diff.mean())
    changed_ratio = float((diff >= pixel_threshold).mean())
    return mean_difference, changed_ratio


def send_discord(cfg: dict[str, Any], message: str) -> None:
    webhook = cfg.get("discord_webhook_url", "").strip()
    if not webhook:
        return
    payload = json.dumps({"content": message}, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        webhook,
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": f"StreamMonitor/{VERSION}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            if response.status >= 300:
                raise RuntimeError(f"Discord antwortete mit HTTP {response.status}")
    except Exception:
        logging.exception("Discord-Benachrichtigung fehlgeschlagen")


@dataclass
class CameraState:
    previous: np.ndarray | None = None
    previous_raw: np.ndarray | None = None
    current_raw: np.ndarray | None = None
    unchanged_since: float | None = None
    last_recovery: float = 0.0
    recovery_count: int = 0
    notified_frozen: bool = False


class ObsFreezeMonitor:
    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        self.states = {item["name"]: CameraState() for item in cfg.get("cameras", [])}
        self.client: Any | None = None
        self.connection_state = "starting"
        self.last_connection_error: str | None = None

    def connect(self):
        if self.client is not None:
            return self.client
        if obs is None:
            raise RuntimeError("Python-Paket obsws-python fehlt. EINRICHTEN.cmd erneut ausführen.")
        self.client = obs.ReqClient(
            host=self.cfg.get("host", "127.0.0.1"),
            port=int(self.cfg.get("port", 4455)),
            password=self.cfg.get("password", ""),
            timeout=float(self.cfg.get("timeout_seconds", 8)),
        )
        logging.info("OBS-WebSocket verbunden: %s:%s", self.cfg.get("host", "127.0.0.1"), self.cfg.get("port", 4455))
        if self.connection_state == "reconnecting":
            logging.info("OBS-Verbindung wiederhergestellt; reguläre Prüfungen werden fortgesetzt.")
        self.connection_state = "running"
        self.last_connection_error = None
        return self.client

    def disconnect(self) -> None:
        if self.client is not None:
            try:
                self.client.disconnect()
            except Exception:
                pass
            self.client = None

    def screenshot(self, client: Any, camera: dict[str, Any]) -> np.ndarray:
        response = client.get_source_screenshot(
            camera["screenshot_source_name"],
            "jpg",
            int(self.cfg.get("screenshot_width", 640)),
            int(self.cfg.get("screenshot_height", 360)),
            int(self.cfg.get("jpeg_quality", 70)),
        )
        data = response_value(response, "image_data", "imageData")
        return decode_obs_screenshot(data)

    def trim_event_folders(self) -> None:
        maximum = max(1, int(self.cfg.get("max_event_folders", 50)))
        OBS_EVENT_DIR.mkdir(parents=True, exist_ok=True)
        folders = sorted((p for p in OBS_EVENT_DIR.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
        for folder in folders[maximum:]:
            import shutil
            shutil.rmtree(folder, ignore_errors=True)

    def save_event(self, camera: dict[str, Any], state: CameraState, reason: str, metrics: dict[str, Any]) -> Path | None:
        if not self.cfg.get("save_on_event", True):
            return None
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in camera["name"])
        folder = OBS_EVENT_DIR / f"{stamp}_{safe}"
        folder.mkdir(parents=True, exist_ok=True)
        if state.previous_raw is not None:
            cv2.imwrite(str(folder / "previous.jpg"), state.previous_raw)
        if state.current_raw is not None:
            cv2.imwrite(str(folder / "current.jpg"), state.current_raw)
        if state.previous_raw is not None and state.current_raw is not None and state.previous_raw.shape == state.current_raw.shape:
            diff = cv2.absdiff(state.previous_raw, state.current_raw)
            cv2.imwrite(str(folder / "difference.jpg"), diff)
        event = {
            "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
            "camera": camera["name"],
            "reason": reason,
            "metrics": metrics,
        }
        atomic_json_write(folder / "event.json", event)
        self.trim_event_folders()
        logging.info("OBS-Ereignisbilder gespeichert: %s", folder)
        return folder

    def recover(self, client: Any, camera: dict[str, Any]) -> None:
        scene = camera["recovery_parent_scene"]
        source = camera["recovery_scene_item"]
        response = client.get_scene_item_id(scene, source)
        item_id = int(response_value(response, "scene_item_id", "sceneItemId"))
        write_camera_status(camera["name"], "recovering", f"{source} wird kurz ausgeblendet.")
        client.set_scene_item_enabled(scene, item_id, False)
        time.sleep(float(self.cfg.get("recovery_invisible_seconds", 4)))
        client.set_scene_item_enabled(scene, item_id, True)
        time.sleep(float(self.cfg.get("recovery_settle_seconds", 12)))

    def check_camera(self, client: Any, camera: dict[str, Any], now: float) -> None:
        name = camera["name"]
        state = self.states[name]
        image = self.screenshot(client, camera)
        state.previous_raw = state.current_raw
        state.current_raw = image
        current = normalized_frame(image, camera.get("analysis_roi"))
        if state.previous is None:
            state.previous = current
            state.unchanged_since = now
            write_camera_status(name, "starting", "Erstes Vergleichsbild gespeichert.")
            return

        mean_diff, changed_ratio = image_change(
            state.previous, current, int(self.cfg.get("pixel_difference_threshold", 6))
        )
        state.previous = current
        changed = (
            mean_diff >= float(self.cfg.get("minimum_mean_difference", 0.9))
            or changed_ratio >= float(self.cfg.get("minimum_changed_pixel_ratio", 0.012))
        )

        if changed:
            was_suspicious = state.unchanged_since is not None and (
                now - state.unchanged_since >= float(self.cfg.get("freeze_after_minutes", 8)) * 60
            )
            state.unchanged_since = now
            state.recovery_count = 0
            state.notified_frozen = False
            write_camera_status(
                name,
                "recovered" if was_suspicious else "ok",
                f"Änderung erkannt: Mittel {mean_diff:.3f}, Pixel {changed_ratio:.3%}",
                mean_difference=round(mean_diff, 3),
                changed_pixel_ratio=round(changed_ratio, 5),
                unchanged_minutes=0,
            )
            return

        if state.unchanged_since is None:
            state.unchanged_since = now
        unchanged_minutes = (now - state.unchanged_since) / 60
        freeze_after = float(self.cfg.get("freeze_after_minutes", 8))
        if unchanged_minutes < freeze_after:
            write_camera_status(
                name,
                "ok",
                f"Aktuell wenig Bewegung: {unchanged_minutes:.1f} min",
                mean_difference=round(mean_diff, 3),
                changed_pixel_ratio=round(changed_ratio, 5),
                unchanged_minutes=round(unchanged_minutes, 1),
            )
            return

        write_camera_status(
            name,
            "suspected",
            f"Seit {unchanged_minutes:.1f} min nahezu unverändert.",
            mean_difference=round(mean_diff, 3),
            changed_pixel_ratio=round(changed_ratio, 5),
            unchanged_minutes=round(unchanged_minutes, 1),
        )

        auto_recovery = bool(self.cfg.get("auto_recovery_enabled", False))
        cooldown = float(self.cfg.get("recovery_cooldown_minutes", 30)) * 60
        max_recoveries = int(self.cfg.get("max_recoveries_per_freeze", 1))
        can_recover = (
            auto_recovery
            and state.recovery_count < max_recoveries
            and now - state.last_recovery >= cooldown
        )
        if can_recover:
            logging.warning("Freeze-Verdacht bei %s; OBS-Quelle wird neu geladen.", name)
            self.recover(client, camera)
            state.last_recovery = time.time()
            state.recovery_count += 1
            state.previous = None
            return

        if not state.notified_frozen:
            state.notified_frozen = True
            self.save_event(camera, state, "freeze_suspected", {
                "mean_difference": round(mean_diff, 3),
                "changed_pixel_ratio": round(changed_ratio, 5),
                "unchanged_minutes": round(unchanged_minutes, 1),
            })
            message = (
                f"⚠️ StreamMonitor: OBS-Bild '{name}' ist seit "
                f"{unchanged_minutes:.1f} Minuten nahezu unverändert."
            )
            logging.warning(message)
            send_discord(self.cfg.get("notifications", {}), message)
            write_camera_status(name, "frozen", message, unchanged_minutes=round(unchanged_minutes, 1))

    def check_all(self) -> bool:
        """Prüft alle Kameras und meldet, ob OBS erreichbar war.

        Der Rückgabewert steuert ausschließlich den Zeitpunkt des nächsten
        Versuchs: reguläres Prüfintervall bei Erfolg, separates
        Wiederverbindungsintervall bei nicht erreichbarem OBS.
        """
        if not self.cfg.get("enabled", False):
            for camera in self.cfg.get("cameras", []):
                write_camera_status(camera["name"], "disabled")
            return True
        try:
            client = self.connect()
            now = time.time()
            for camera in self.cfg.get("cameras", []):
                if not camera.get("enabled", True):
                    write_camera_status(camera["name"], "disabled")
                    continue
                try:
                    self.check_camera(client, camera, now)
                    logging.info("OBS-Prüfung %s erfolgreich", camera["name"])
                except Exception as exc:
                    logging.exception("OBS-Prüfung für %s fehlgeschlagen", camera["name"])
                    write_camera_status(camera["name"], "error", str(exc))
            return True
        except Exception as exc:
            message = str(exc)
            first_failure = self.connection_state != "reconnecting"
            changed_error = message != self.last_connection_error
            self.connection_state = "reconnecting"
            self.last_connection_error = message
            self.disconnect()
            reconnect_seconds = max(10, int(self.cfg.get("reconnect_interval_seconds", 60)))
            if first_failure or changed_error:
                logging.warning(
                    "OBS-WebSocket nicht erreichbar: %s | Neuer Versuch in %s Sekunden",
                    message,
                    reconnect_seconds,
                )
            else:
                logging.info("OBS weiterhin nicht erreichbar; nächster Versuch in %s Sekunden", reconnect_seconds)
            for camera in self.cfg.get("cameras", []):
                write_camera_status(
                    camera["name"],
                    "offline",
                    f"OBS nicht erreichbar; neuer Versuch in {reconnect_seconds} Sekunden.",
                )
            return False



class PumpMonitor:
    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        self.last_state: str | None = None
        self.last_error: str | None = None

    def check(self) -> bool:
        if not self.cfg.get("enabled", False):
            write_pump_status("disabled")
            return True
        url = str(self.cfg.get("url", "")).strip()
        if not url:
            write_pump_status("error", "Keine Shelly-URL konfiguriert.")
            return False
        timeout = max(1.0, float(self.cfg.get("timeout_seconds", 5)))
        try:
            request = urllib.request.Request(url, headers={"User-Agent": f"StreamMonitor/{VERSION}"})
            with urllib.request.urlopen(request, timeout=timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
            if not isinstance(payload, dict):
                raise RuntimeError("Shelly-Antwort enthält kein JSON-Objekt.")
            switch = payload.get("switch:0")
            output = switch.get("output") if isinstance(switch, dict) and isinstance(switch.get("output"), bool) else None
            detail = "Shelly antwortet mit gültigem JSON."
            if output is not None:
                detail += " Pumpenausgang ist " + ("eingeschaltet." if output else "ausgeschaltet.")
            write_pump_status("online", detail, output=output)
            if self.last_state != "online":
                logging.info("Pumpe erreichbar: %s", url)
            self.last_state = "online"
            self.last_error = None
            return True
        except Exception as exc:
            message = str(exc)
            write_pump_status("offline", message)
            if self.last_state != "offline" or message != self.last_error:
                logging.warning("Pumpe nicht erreichbar: %s", message)
            else:
                logging.info("Pumpe weiterhin nicht erreichbar.")
            self.last_state = "offline"
            self.last_error = message
            return False

def open_folder(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.startfile(str(path))  # type: ignore[attr-defined]
    except AttributeError:
        webbrowser.open(path.resolve().as_uri())



def startup_shortcut_path() -> Path | None:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / AUTOSTART_NAME


def legacy_startup_path() -> Path | None:
    shortcut = startup_shortcut_path()
    return shortcut.with_name("StreamMonitor_starten.vbs") if shortcut else None


def is_autostart_enabled() -> bool:
    shortcut = startup_shortcut_path()
    legacy = legacy_startup_path()
    return bool((shortcut and shortcut.exists()) or (legacy and legacy.exists()))


def _ps_quote(value: str) -> str:
    return value.replace("'", "''")


def set_autostart(enabled: bool) -> None:
    if os.name != "nt":
        raise RuntimeError("Autostart kann nur unter Windows verwaltet werden.")
    shortcut = startup_shortcut_path()
    legacy = legacy_startup_path()
    if shortcut is None:
        raise RuntimeError("Windows-Autostartordner konnte nicht ermittelt werden.")
    shortcut.parent.mkdir(parents=True, exist_ok=True)
    if enabled:
        vbs = BASE / "StreamMonitor_starten.vbs"
        if not vbs.exists():
            raise RuntimeError("StreamMonitor_starten.vbs fehlt.")
        script = (
            "$ws=New-Object -ComObject WScript.Shell;"
            f"$s=$ws.CreateShortcut('{_ps_quote(str(shortcut))}');"
            "$s.TargetPath=$env:WINDIR+'\\System32\\wscript.exe';"
            f"$s.Arguments='\"{_ps_quote(str(vbs))}\"';"
            f"$s.WorkingDirectory='{_ps_quote(str(BASE))}';"
            f"$s.Description='StreamMonitor {VERSION}';"
            "$s.Save()"
        )
        result = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], capture_output=True, text=True)
        if result.returncode != 0 or not shortcut.exists():
            raise RuntimeError((result.stderr or result.stdout or "Verknüpfung konnte nicht erstellt werden.").strip())
        if legacy and legacy.exists():
            legacy.unlink()
    else:
        for path in (shortcut, legacy):
            if path and path.exists():
                path.unlink()

def tray_icon_image():
    if Image is None or ImageDraw is None:
        return None
    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((8, 8, 56, 56), fill=(35, 120, 190, 255))
    draw.polygon([(32, 14), (19, 38), (45, 38)], fill=(255, 255, 255, 255))
    draw.ellipse((24, 33, 40, 49), fill=(255, 255, 255, 255))
    return image


def show_silent_notification(title: str, message: str, duration_seconds: float = 4.0) -> None:
    """Show a small silent desktop toast without using Windows notification audio."""
    def worker() -> None:
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            win = tk.Toplevel(root)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            bg = "#182128"
            win.configure(bg=bg)
            outer = tk.Frame(win, bg=bg, padx=14, pady=10)
            outer.pack()
            tk.Label(outer, text=title, bg=bg, fg="#ffffff", font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x")
            tk.Label(outer, text=message, bg=bg, fg="#d7e0e5", font=("Segoe UI", 9), anchor="w", justify="left", wraplength=330).pack(fill="x", pady=(4, 0))
            win.update_idletasks()
            sw = win.winfo_screenwidth(); sh = win.winfo_screenheight()
            ww = win.winfo_width(); wh = win.winfo_height()
            win.geometry(f"{ww}x{wh}+{max(10, sw-ww-18)}+{max(10, sh-wh-58)}")
            win.after(max(500, int(duration_seconds * 1000)), root.destroy)
            root.mainloop()
        except Exception:
            logging.debug("Stille Tray-Meldung konnte nicht angezeigt werden.", exc_info=True)
    threading.Thread(target=worker, name="SilentTrayNotification", daemon=True).start()


class TrayController:
    def __init__(
        self,
        cfg: dict[str, Any],
        stop_event: threading.Event,
        check_event: threading.Event,
    ) -> None:
        self.cfg = cfg
        self.water_cfg = cfg.get("water_monitor", {})
        self.stop_event = stop_event
        self.check_event = check_event
        self.icon: Any | None = None

    def notify(self, title: str, message: str) -> None:
        logging.info("Tray-Meldung | %s", message)
        notify_cfg = self.cfg.get("notifications", {})
        if bool(notify_cfg.get("silent", True)):
            show_silent_notification(title, message, float(notify_cfg.get("duration_seconds", 4)))
            return
        try:
            if self.icon is not None:
                self.icon.notify(message, title)
        except Exception:
            logging.debug("Tray-Benachrichtigung konnte nicht angezeigt werden.", exc_info=True)

    def _capture(self, state: str) -> None:
        threading.Thread(
            target=create_reference_series,
            args=(state, self.water_cfg, self.notify),
            name=f"ReferenceCapture-{state}",
            daemon=True,
        ).start()

    def _show_roi_diagnostic(self) -> None:
        try:
            show_water_roi_diagnostic()
        except Exception as exc:
            logging.exception("Wasser-Diagnosebild konnte nicht erstellt werden")
            self.notify("StreamMonitor", f"Diagnosebild konnte nicht erstellt werden: {exc}")

    def _show_reference_report(self) -> None:
        try:
            report = write_reference_report()
            open_file(report)
            counts = reference_counts()
            self.notify("StreamMonitor", "Referenzbestand wurde aktualisiert und geöffnet.")
            logging.info("Referenzbestand | %s", " | ".join(f"{key} {value}" for key, value in counts.items()))
        except Exception as exc:
            logging.exception("Referenzbestand konnte nicht erstellt werden")
            self.notify("StreamMonitor", f"Referenzbestand konnte nicht geöffnet werden: {exc}")

    def _reload_references(self) -> None:
        counts = reference_counts()
        message = "Referenzen neu eingelesen: " + ", ".join(f"{key} {value}" for key, value in counts.items())
        logging.info(message)
        self.notify("StreamMonitor", message)

    def _toggle_autostart(self) -> None:
        try:
            enabled = not is_autostart_enabled()
            set_autostart(enabled)
            message = "Autostart aktiviert." if enabled else "Autostart deaktiviert."
            logging.info(message)
            self.notify("StreamMonitor", message)
            if self.icon is not None:
                self.icon.update_menu()
        except Exception as exc:
            logging.exception("Autostart konnte nicht geändert werden")
            self.notify("StreamMonitor", f"Autostart konnte nicht geändert werden: {exc}")

    def start(self) -> None:
        if not bool(self.cfg.get("system_tray", {}).get("enabled", True)):
            logging.info("System-Tray ist deaktiviert.")
            return
        if pystray is None:
            logging.warning("System-Tray nicht verfügbar: Pakete pystray/Pillow fehlen. EINRICHTEN.cmd ausführen.")
            return
        ref_menu = pystray.Menu(
            pystray.MenuItem(tr("water_levels", "full", "Voll"), lambda *_: self._capture("full")),
            pystray.MenuItem(tr("water_levels", "good", "Gut gefüllt"), lambda *_: self._capture("good")),
            pystray.MenuItem(tr("water_levels", "low", "Niedriger Wasserstand"), lambda *_: self._capture("low")),
            pystray.MenuItem(tr("water_levels", "almost_empty", "Fast leer"), lambda *_: self._capture("almost_empty")),
            pystray.MenuItem(tr("water_levels", "empty", "Leer"), lambda *_: self._capture("empty")),
        )
        menu = pystray.Menu(
            pystray.MenuItem("Status öffnen", lambda *_: webbrowser.open(f"http://127.0.0.1:{int(self.cfg.get('overlay_port', 8765))}/status.html"), default=True),
            pystray.MenuItem("Jetzt prüfen", lambda *_: self.check_event.set()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Neue Wasser-Referenz", ref_menu),
            pystray.MenuItem("Referenzen neu einlesen", lambda *_: self._reload_references()),
            pystray.MenuItem("Referenzbestand anzeigen", lambda *_: self._show_reference_report()),
            pystray.MenuItem("Diagnosebild mit ROI anzeigen", lambda *_: self._show_roi_diagnostic()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Referenzordner öffnen", lambda *_: open_folder(REF_DIR)),
            pystray.MenuItem("Referenzarchiv öffnen", lambda *_: open_folder(REF_ARCHIVE_DIR)),
            pystray.MenuItem("Logordner öffnen", lambda *_: open_folder(LOG_FILE.parent)),
            pystray.MenuItem("Diagnoseordner öffnen", lambda *_: open_folder(BASE / "diagnostics" / "water")),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Beim Windows-Start starten", lambda *_: self._toggle_autostart(), checked=lambda _: is_autostart_enabled()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Beenden", lambda *_: self.stop_event.set()),
        )
        self.icon = pystray.Icon("StreamMonitor", tray_icon_image(), f"StreamMonitor {VERSION}", menu)
        self.icon.run_detached()
        logging.info("System-Tray gestartet")

    def stop(self) -> None:
        if self.icon is not None:
            try:
                self.icon.stop()
            except Exception:
                logging.debug("System-Tray konnte nicht sauber beendet werden.", exc_info=True)


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, *_: Any) -> None:
        pass

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        super().end_headers()


def serve(port: int) -> ThreadingHTTPServer:
    os.chdir(BASE / "overlay")
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def main() -> None:
    cfg = load_cfg()
    setup_log([str(cfg.get("obs_monitor", {}).get("password", ""))])
    load_translations(str(cfg.get("language", "de")))
    once = "--once" in sys.argv
    no_delay = "--no-delay" in sys.argv
    water_cfg = cfg.get("water_monitor", {})
    obs_cfg = cfg.get("obs_monitor", {})
    pump_cfg = cfg.get("pump_monitor", {})
    logging.info("=" * 56)
    logging.info("StreamMonitor %s Release", VERSION)
    logging.info("Start: %s", datetime.now().astimezone().isoformat(timespec="seconds"))
    logging.info("RTMP      : %s", "aktiviert" if water_cfg.get("enabled", False) else "deaktiviert")
    logging.info("OBS       : %s", "aktiviert" if obs_cfg.get("enabled", False) else "deaktiviert")
    logging.info("Pumpe     : %s", "aktiviert" if pump_cfg.get("enabled", False) else "deaktiviert")
    logging.info("Overlay   : aktiviert")
    logging.info("Autostart : %s", "aktiviert" if is_autostart_enabled() else "deaktiviert")
    logging.info("=" * 56)
    server = serve(int(cfg.get("overlay_port", 8765)))
    stop = threading.Event()
    check_now = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, lambda *_: stop.set())

    write_pump_status("starting" if pump_cfg.get("enabled", False) else "disabled")
    for camera in obs_cfg.get("cameras", []):
        write_camera_status(camera["name"], "starting" if camera.get("enabled", True) else "disabled")

    tray = TrayController(cfg, stop, check_now)
    if not once:
        tray.start()
    if not once and not no_delay:
        stop.wait(float(cfg.get("startup_delay_seconds", 60)))

    obs_monitor = ObsFreezeMonitor(obs_cfg)
    pump_monitor = PumpMonitor(pump_cfg)
    water_tracker = WaterStateTracker()
    water_next = 0.0
    obs_next = 0.0
    pump_next = 0.0
    measure_lock = threading.Lock()

    try:
        while not stop.is_set():
            now = time.monotonic()
            manual_check = check_now.is_set()
            if manual_check:
                check_now.clear()
                logging.info("Manuelle Prüfung über System-Tray angefordert")
            if once or manual_check or now >= water_next:
                if measure_lock.acquire(blocking=False):
                    try:
                        measure_water(water_cfg, water_tracker)
                    finally:
                        measure_lock.release()
                else:
                    logging.info("Wassermessung übersprungen: Eine Aufnahme läuft bereits.")
                normal_interval = max(1, int(water_cfg.get("interval_minutes", 5))) * 60
                transition_interval = max(10, int(water_cfg.get("transition_check_interval_seconds", 60)))
                transition_checks = max(0, int(water_cfg.get("transition_fast_checks", 3)))
                if water_tracker.state_changed:
                    water_tracker.state_changed = False
                    water_next = time.monotonic() + transition_interval
                    water_tracker.fast_check_remaining = transition_checks
                elif getattr(water_tracker, "fast_check_remaining", 0) > 0:
                    water_tracker.fast_check_remaining -= 1
                    water_next = time.monotonic() + transition_interval
                elif water_tracker.candidate is not None:
                    water_next = time.monotonic() + transition_interval
                else:
                    water_next = time.monotonic() + normal_interval
            if once or manual_check or now >= obs_next:
                obs_available = obs_monitor.check_all()
                interval_key = "check_interval_seconds" if obs_available else "reconnect_interval_seconds"
                obs_next = time.monotonic() + max(10, int(obs_cfg.get(interval_key, 60)))
            if once or manual_check or now >= pump_next:
                pump_available = pump_monitor.check()
                interval_key = "check_interval_seconds" if pump_available else "reconnect_interval_seconds"
                pump_next = time.monotonic() + max(10, int(pump_cfg.get(interval_key, 60)))
            if once:
                break
            next_due = min(water_next, obs_next, pump_next)
            stop.wait(max(0.2, min(2.0, next_due - time.monotonic())))
    finally:
        obs_monitor.disconnect()
        tray.stop()
        server.shutdown()
        logging.info("StreamMonitor beendet")


if __name__ == "__main__":
    main()
