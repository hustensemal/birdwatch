@echo off
del /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\StreamMonitor.lnk" 2>nul
del /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\StreamMonitor_starten.vbs" 2>nul
echo Autostart wurde deaktiviert.
pause
