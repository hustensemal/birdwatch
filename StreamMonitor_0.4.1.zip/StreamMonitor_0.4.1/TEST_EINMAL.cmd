@echo off
cd /d "%~dp0"
python StreamMonitor.py --once --no-delay
 echo.
 echo Test beendet. Bitte Log unter logs\streammonitor.log pruefen.
pause
