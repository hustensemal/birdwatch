@echo off
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install opencv-python numpy obsws-python pystray Pillow
if not exist data\references\full mkdir data\references\full
if not exist data\references\good mkdir data\references\good
if not exist data\references\low mkdir data\references\low
if not exist data\references\almost_empty mkdir data\references\almost_empty
if not exist data\references\empty mkdir data\references\empty
if not exist data\snapshots mkdir data\snapshots
if not exist data\obs_snapshots mkdir data\obs_snapshots
if not exist logs mkdir logs
pause
