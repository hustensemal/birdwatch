@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $p=[Environment]::GetFolderPath('Startup')+'\\StreamMonitor.lnk'; $s=$ws.CreateShortcut($p); $s.TargetPath=$env:WINDIR+'\\System32\\wscript.exe'; $s.Arguments='""%~dp0StreamMonitor_starten.vbs""'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Autostart wurde aktiviert.
pause
