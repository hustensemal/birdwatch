@echo off
cd /d "%~dp0"
python OBS_NAMEN_TESTEN.py
