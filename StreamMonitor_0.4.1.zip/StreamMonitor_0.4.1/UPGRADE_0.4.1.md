# StreamMonitor 0.4.1 – Upgrade-Hinweise

## Wasserprüfung
- Normalintervall: 5 Minuten
- Bei einem laufenden Kandidaten bzw. bestätigten Zustandswechsel: Folgeprüfung nach 60 Sekunden
- Danach Rückkehr zum normalen Intervall

## Streamer.Bot
Die Schnittstelle liegt im Ordner `streamerbot/`:
- `water_level.txt`
- `water_allowed.txt`
- `water_status.json`

Die Sperre bei `full` ist standardmäßig aktiv und kann in `config.json` über `streamerbot_export.block_water_when_full` deaktiviert werden.

## Benachrichtigungen
Normale Tray-Meldungen werden standardmäßig als stille Desktop-Meldungen angezeigt. `notifications.silent` kann auf `false` gesetzt werden, um wieder die native Windows-Benachrichtigung zu verwenden.

## Diagnose
Im Tray steht `Diagnosebild mit ROI anzeigen` zur Verfügung. Es wird ein einzelnes Bild aus dem zuletzt ausgewerteten Frame geöffnet; es wird kein zusätzlicher Videostream gestartet.
