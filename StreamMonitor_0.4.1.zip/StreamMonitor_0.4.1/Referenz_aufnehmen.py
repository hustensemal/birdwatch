import json
import sys
import time
from pathlib import Path

import cv2

BASE = Path(__file__).resolve().parent
cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8"))["water_monitor"]
STATES = ("full", "good", "low", "almost_empty", "empty")

if len(sys.argv) != 2 or sys.argv[1] not in STATES:
    raise SystemExit("Klasse fehlt. Erlaubt: " + ", ".join(STATES))

cap = cv2.VideoCapture(cfg["stream_url"], cv2.CAP_FFMPEG)
if not cap.isOpened():
    raise SystemExit("Stream konnte nicht geöffnet werden.")
for _ in range(20):
    cap.read()
    time.sleep(0.05)
ok, frame = cap.read()
cap.release()
if not ok or frame is None:
    raise SystemExit("Kein Bild empfangen.")

folder = BASE / "data" / "references" / sys.argv[1]
folder.mkdir(parents=True, exist_ok=True)
stamp = time.strftime("%Y%m%d_%H%M%S")
path = folder / f"{stamp}_fullframe.png"
cv2.imwrite(str(path), frame)

fh, fw = frame.shape[:2]
nx, ny, nw, nh = cfg["roi_normalized"]
x, y, w, h = round(nx * fw), round(ny * fh), max(1, round(nw * fw)), max(1, round(nh * fh))
preview = frame[max(0, y):min(fh, y+h), max(0, x):min(fw, x+w)]
preview_dir = BASE / "data" / "reference_previews" / sys.argv[1]
preview_dir.mkdir(parents=True, exist_ok=True)
preview_path = preview_dir / f"{stamp}_roi.png"
cv2.imwrite(str(preview_path), preview)

print("Vollbild-Referenz gespeichert:", path)
print("ROI-Kontrollbild gespeichert:", preview_path)
print("ROI in Pixeln:", [x, y, w, h], "bei", [fw, fh])
