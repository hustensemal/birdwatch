Dateien in diesem Archiv werden von StreamMonitor nicht ausgewertet.
Zum Reaktivieren in den passenden Klassenordner unter data\references zurückverschieben.
