# Changelog

## 0.4.1 – Stabilisierung und Schnittstellen

- Wasserprüfung im Normalbetrieb standardmäßig alle 5 Minuten.
- Schnellere Folgeprüfungen bei erkannten Zustandswechseln bzw. laufender Bestätigung.
- Stille Desktop-Meldungen ohne Windows-Benachrichtigungston.
- Diagnosebild aus dem zuletzt tatsächlich ausgewerteten Frame mit eingezeichnetem ROI.
- Belichtungsnormalisierung im ROI als parallele Vergleichsanalyse; sie entscheidet zunächst nicht über den offiziellen Status.
- Streamer.Bot-Export: `water_level.txt`, `water_allowed.txt` und `water_status.json`.
- Konfigurierbare Sperre der Wasserfunktion bei `full`, standardmäßig aktiviert.


## 0.4.0 – Release

- Shelly-/Pumpenmonitor über `Shelly.GetStatus`
- Kompaktes OBS-Overlay für Wasserstand, Erkennung, Pumpe und Stream
- Windows-Autostart direkt im Tray aktivierbar und deaktivierbar
- Eigene Statusseite unter `/status.html`
- Einheitlicher Startblock im Log
- Robustere Initialisierung der Statusdatei
- Autostart-Verknüpfung verweist korrekt auf den Installationsordner

## 0.3.9

- Adaptive Hysterese
- Referenzbestand und Referenzarchiv
