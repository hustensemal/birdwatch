# StreamMonitor 0.4.1

Erste für den Dauerbetrieb vorgesehene Release-Version.

## Einrichtung

1. `EINRICHTEN.cmd` ausführen.
2. In `config.json` RTMP-Zugang und OBS-WebSocket-Passwort eintragen.
3. Die Shelly-Adresse unter `pump_monitor.url` prüfen.
4. `StreamMonitor_starten.vbs` starten.

## Autostart

Im Tray-Menü kann **Beim Windows-Start starten** jederzeit aktiviert oder deaktiviert werden. Der Haken zeigt den tatsächlich vorhandenen Windows-Autostart-Eintrag an.

## Overlay

OBS-Browserquelle: `http://127.0.0.1:8765/`

Empfohlene Größe: etwa 190 × 125 Pixel.

Statusseite: `http://127.0.0.1:8765/status.html`

## Hinweise

Die Wasserstandserkennung bleibt experimentell. Pumpenstatus und Streamstatus werden unabhängig davon angezeigt.


## 0.4.1

Die Wasserstandsmessung läuft standardmäßig alle 5 Minuten. Bei einem erkannten Zustandswechsel oder einer laufenden Bestätigung werden kurzfristig Folgeprüfungen im Abstand von 60 Sekunden durchgeführt.

Normale Tray-Meldungen werden standardmäßig als stille Desktop-Meldung angezeigt und erzeugen keinen Ton.

Über das Tray kann ein einzelnes Diagnosebild mit dem ROI des zuletzt ausgewerteten Bildes geöffnet werden.

### Streamer.Bot

StreamMonitor schreibt bei aktivierter Schnittstelle in `streamerbot/`: `water_level.txt`, `water_allowed.txt` und `water_status.json`. Bei `full` wird die Wasserfunktion standardmäßig gesperrt. Diese Sperre kann über `streamerbot_export.block_water_when_full` deaktiviert werden.
