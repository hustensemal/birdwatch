@echo off
cd /d "%~dp0"
echo 1 = voll
echo 2 = gut gefuellt
echo 3 = niedrig
echo 4 = fast leer
echo 5 = leer
set /p C=Auswahl: 
if "%C%"=="1" set S=full
if "%C%"=="2" set S=good
if "%C%"=="3" set S=low
if "%C%"=="4" set S=almost_empty
if "%C%"=="5" set S=empty
if "%S%"=="" (
 echo Ungueltige Auswahl.
 pause
 exit /b 1
)
py Referenz_aufnehmen.py %S%
pause
